# Yuxi Cui
# Shengnan Sun
# How can We Understand Mircobiome
#   -- Using Python to achieve core functions of Parallel-META 3


import os
import csv
import math
import sys


# statistics dependency
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns
import scipy
from scipy import stats
import skbio
from pylab import plot, show, savefig, xlim, figure, hold, ylim, legend, boxplot, setp, axes
from numpy import std, mean, sqrt


#########################
## raw data processing ##
#########################
# author: Yuxi Cui


# takes the argument from the user specifying sample file directory
path = sys.argv[1]

# post: return a list containing sample names sorted by health status, excluding hidden files.
def clean_sample_directory():
    temp = os.listdir(path + '/samples/')
    cleaned_path = []
    for d in temp:
        if d[0] == '.':
            temp.remove(d)
    for d in temp:
        if 'B' in d:
            cleaned_path.append(d)
    for d in temp:
        if 'I' in d:
            cleaned_path.append(d)
    return cleaned_path

pathDir = clean_sample_directory()


#############################################
# compute the alpha diversity of the samples#
#############################################


# pre: sub is a substring of string s, n is the number of appearance of sub and 0 < n <= max appearance of sub in s
# post: return the index of the nth appearance of sub in s
def nth_index_of(sub, s, n):
    index = s.find(sub)
    if index == -1:
        return -1
    if n > 0:
        return index + 1 + nth_index_of(sub, s[s.find(sub) + 1:], n - 1)
    else:
        return 0


# pre: takes a list abd containing the abundance number of a sample
# post: return the Shannon-Wienner index of that sample
def compute_shannon(abd_l):
    res = 0.0
    for abd in abd_l:
        if abd > 0:
            res += abd * math.log(abd)
    return -1.0 * res


# count the total number of species and otus in the sample
allOTUs = ['']
allGenus = ['']
allAlpha = ['', "Observed OTU", "Shannon Index"]


# gather names of all OTU and genus
for i in range(0, len(pathDir)):
    f = open(path + '/samples/' + pathDir[i] + "/classification.txt", "r")
    line1 = f.readline()
    data = f.readlines()
    for line in data:
        genus = line[nth_index_of("; ", line, 5) + 1: nth_index_of(";", line, 6) - 1]
        family = line[nth_index_of("; ", line, 4) + 1: nth_index_of(";", line, 5) - 1]
        name = family[0:3] + "_" + genus
        if name not in allGenus:
            allGenus.append(name)

        otu = line[nth_index_of("; ", line, 7) + 1:]
        if otu not in allOTUs:
            allOTUs.append(otu)

# make count table, abundance table, and alpha diversity table at genus and OTU level
genusCountTable = []
genusAbdTable = []
genusAlphaTable = []

otuCountTable = []
otuAbdTable = []
otuAlphaTable = []

for i in range(0, len(pathDir)):
    f = open(path + '/samples/' + pathDir[i] + "/classification.txt", "r")
    f.readline()
    data = f.readlines()
    total = 0

    genusDic = {}
    genusCountTemp = [pathDir[i]]
    genusAbdTemp = [pathDir[i]]
    genusAlphaTemp = [pathDir[i]]

    otuDic = {}
    otuCountTemp = [pathDir[i]]
    otuAbdTemp = [pathDir[i]]
    otuAlphaTemp = [pathDir[i]]

    # count
    for line in data:
        total += 1.0
        genus = line[nth_index_of("; ", line, 5) + 1: nth_index_of(";", line, 6) - 1]
        family = line[nth_index_of("; ", line, 4) + 1: nth_index_of(";", line, 5) - 1]
        name = family[0:3] + "_" + genus
        otu = line[nth_index_of("; ", line, 7) + 1:]

        # make genus dictionary
        if name in genusDic:
            genusDic[name] += 1
        else:
            genusDic[name] = 1

        # make otu dictionary
        if otu in otuDic:
            otuDic[otu] += 1
        else:
            otuDic[otu] = 1


    # make genus count table and abundance table
    for g in allGenus:
        if g in genusDic:
            genusCountTemp.append(genusDic[g])
            genusAbdTemp.append(genusDic[g] / total)

        elif g != '':
            genusCountTemp.append(0)
            genusAbdTemp.append(0.0)
    genusCountTable.append(genusCountTemp)
    genusAbdTable.append(genusAbdTemp)

    genusAlphaTemp.append(len(genusDic.keys()))
    genusAlphaTemp.append(compute_shannon(genusAbdTemp[1:]))
    genusAlphaTable.append(genusAlphaTemp)

    # make otu count table and abundance table
    for o in allOTUs:
        if o in otuDic:
            otuCountTemp.append(otuDic[o])
            otuAbdTemp.append(otuDic[o] / total)
        elif o != '':
            otuCountTemp.append(0)
            otuAbdTemp.append(0.0)
    otuCountTable.append(otuCountTemp)
    otuAbdTable.append(otuAbdTemp)

    otuAlphaTemp.append(len(otuDic.keys()))
    otuAlphaTemp.append(compute_shannon(otuAbdTemp[1:]))
    otuAlphaTable.append(otuAlphaTemp)


# pre:takes a 2D list specifying which alpha diversity table is being manipulated
# post: insert meta information at the certain alpha diversiyt table using 'meta.txt'
def insert_meta(table):
    fs = open(path + '/meta.txt')
    fs.readline()
    data = fs.readlines()
    for line in data:
        c = line.split('\t')
    if c[0] == table[i][0]:
        table[i].append(c[1])
        table[i].append(c[2])
        table[i].append(c[3])
    fs.close()

insert_meta(otuAbdTable)
insert_meta(genusAbdTable)


# pre: takes the destination directory, the head of the file (first row, typically names),
#      and the body of the file(2-D list)
# post: generate a csv file at destination directory with '\t' as separation
def write_csv(directory, head, body):
    csvfile = file(directory, 'wb')
    writer = csv.writer(csvfile)
    if head != '':
        writer.writerow(head)
    writer.writerows(body)
    csvfile.close()

write_csv(path + '/genusCount.csv', allGenus, genusCountTable)  # Write genus count table
write_csv(path + '/genusAbd.csv', allGenus, genusAbdTable)  # Write genus abundance table
write_csv(path + '/otuCount.csv', allOTUs, otuCountTable)  # Write OTU count table
write_csv(path + '/otuAbd.csv', allOTUs, otuAbdTable)  # Write OTU abundance table
write_csv(path + '/genusAlpha.csv', allAlpha + ['Status', 'Sex', 'Smoking'], genusAbdTable)  # Write genus alpha table
write_csv(path + '/otuAlpha.csv', allAlpha + ['Status', 'Sex', 'Smoking'], otuAlphaTable)  # Write otu alpha table


# write temoporary csv files used by later statistical analysis
temp = [['', 'Status']]
for i in range(1, len(otuAlphaTable)):
    temp.append([otuAlphaTable[i][0], otuAlphaTable[i][3]])
write_csv(path + '/biofeature.csv', '', temp)

temp[0].append('Sex')
temp[0].append('Smoking')
for i in range(1, len(otuAlphaTable)):
    temp[i].append(otuAlphaTable[i][4])
    temp[i].append(otuAlphaTable[i][5])
write_csv(path + '/feature_df.csv', '', temp)


############################################
# compute the beta diversity of the samples#
############################################


class TreeNode (object):

    # constructor of the class
    def __init__(self, name, distance):
        self.name = name
        self.distance = distance
        self.left = None
        self.right = None
        self.ancestor = None
        self.brother = None
        self.p1 = 0.0
        self.p2 = 0.0

    # post: return true if the current node has no child, false otherwise
    def is_leaf_node(self):
        return (self.left is None) & (self.right is None)

    # post: return the brother node of the current node
    def brother(self):
        if self.ancestor.left == self:
            return self.ancestor.right
        else:
            return self.ancestor.left


# pre: takes the name of the otu and the sample name (both Strings)
# post: return the relative abundance of name in sample
def get_abd(name, sample):
    for i in range(0, len(otuAbdTable)):
        if otuAbdTable[i][0] == sample:
            for j in range(0, len(otuAbdTable[0])):
                if otuAbdTable[0][j] == name:
                    return otuAbdTable[i][j]
    return 0.0


# pre: take a string that is in strict newick tree format where only the leaf node and all distance is shown
# post: convert the tree in newick format into binary tree format and return the root TreeNode
def newick_to_tree(st):
    if ',' not in st:  # leaf node
        data = st.split(':')
        return TreeNode(data[0], float(data[1]))
    else:
        dist = float(st[st.rfind(':') + 1:])
        mod = st[1:st.rfind(')')]
        sepIndex = sep_commna_index(mod)
        left = mod[0:sepIndex]
        right = mod[sepIndex + 1:]
        res = TreeNode('FAKE', dist)
        res.left = newick_to_tree(left)
        res.right = newick_to_tree(right)
        res.left.ancestor = res
        res.right.ancestor = res
        res.left.brother = res.right
        res.right.brother = res.left
        return res


# pre: helper method for newick_to_tree, takes a string in newick format and
#      return the index of the comma that separates left and right children
# post: return the index of the comma that separates the 2 children of the current node
def sep_commna_index(st):
    lf = st[0 : st.rfind(',')]
    rt = st[st.rfind(',') + 1:]
    if ')' not in rt:
        return st.rfind(',')
    else:
        rtCount = rt.count(')')
        lfCount = 0
        index = len(lf) - 1
        for c in lf[::-1]:
            if lfCount == rtCount:
                return index
            else:
                index -= 1
                if c == '(':
                    lfCount += 1
                elif c == ')':
                    rtCount += 1
        return index


# pre: takes a TreeNode containing information about the species name and evolutionary distance of a phlyogenetic tree
# post: return a string that represents the tree in Newick format
def tree_to_newick(node):
    if node != None:
        if (node.is_leaf_node()):
            return node.name + ':' + str(node.distance)
        else:
           return '(' + tree_to_newick(node.left) + ',' + tree_to_newick(node.right) + ')' + ':' + str(node.distance)
    else:
        return ''


# pre: takes a root tree node curr
# post: parse through the tree and reset field p1 and p2 to 0
def zero(curr):
    curr.p1 = 0.0
    curr.p2 = 0.0
    if not curr.is_leaf_node():
        zero(curr.left)
        zero(curr.right)


# pre: takes a tree node curr, a sample name s1, and another sample name s2
# post: recalculate the relative abundance of the ancestor of the current tree node according to Meta-Storms Algorithm
def reduce(curr, s1, s2):
    if curr.is_leaf_node():
        curr.p1 = get_abd(curr.name, s1)
        curr.p2 = get_abd(curr.name, s2)
    m = min(curr.p1, curr.p2)
    if curr.ancestor != None:
        curr.ancestor.p1 += (1 - curr.distance) * (curr.p1 - m)
        curr.ancestor.p2 += (1 - curr.distance) * (curr.p2 - m)


# pre: takes a tree node curr, a sample name s1, and another sample name s2
# post: calculate the similarity score of the two sample that can be used to calculate their beta diversity
def get_similarity(curr, s1, s2):
    if curr.is_leaf_node():
        reduce(curr, s1, s2)
        return min(curr.p1, curr.p2)
    else:
        childScore = get_similarity(curr.left, s1, s2) + get_similarity(curr.right, s1, s2)
        reduce(curr, s1, s2)
        return childScore + min(curr.p1, curr.p2)


# make the reference binary tree using 'database.txt'
datafile = open(path + '/database.txt')
ref = datafile.read()
datafile.close()
refTree = newick_to_tree(ref)



# insert all OTU names in the first row of otuAbdTable
name = ['']
for i in range(1, len(allOTUs)):
    name.append(allOTUs[i].split('otu_')[1].split('\n')[0])
otuAbdTable.insert(0, name)


# pre: takes two strings, sample name s1 and s2
# post: return the Euclidean distance between s1 and s2
def get_eu_dist(s1, s2):
    dist = 0.0
    ind1 = 0
    ind2 = 0
    for i in range(0, len(otuAbdTable)):
        if otuAbdTable[i][0] == s1:
            ind1 += i
        if otuAbdTable[i][0] == s2:
            ind2 += i
    for j in range(1, len(otuAbdTable[ind1])):
        dist += ((otuAbdTable[ind1][j] - otuAbdTable[ind2][j]) ** 2)
    return math.sqrt(dist)


# pre: takes a string speicifying what kind of distance matrix to make
# post: return the distance matrix of the certain kind
def make_dist_matrix(measurement):
    matrix = [['']]
    for d in pathDir:
        matrix[0].append(d)
        matrix.append([d])
    for i in range(1, len(matrix)[0]):
        for j in range(1, len(matrix)):
            if i != j:
                zero(refTree)
                if measurement == 'ms':
                    matrix[j].append(1.0 - get_similarity(refTree, matrix[0][i], matrix[j][0]))
                elif measurement == 'eu':
                    matrix[j].append(get_eu_dist(matrix[0][i], matrix[j][0]))
            else:
                matrix[j].append(0.0)
    return matrix

write_csv(path + '/msDistMatrix.csv', '', make_dist_matrix('ms'))  # Write meta storm distance matrix table to a csv file
write_csv(path + '/euDistMatrix.csv', '', make_dist_matrix('eu'))  # Write Eucladian distance matrix table to a csv file


###############################
## Statistical analysis part ##
###############################
# author: Shengnan Sun


# input is the genusAlpha.csv generate before
def alpha_analysis(path):
    # input data frame contains columns of shannon index, following by feature of each sample. Row names are sample ID.
    alpha_df=pd.read_csv(path + '/genusAlpha.csv',index_col=0)
    alpha_df=alpha_df.drop(alpha_df.columns[0], axis=1)

    # create a feature list
    features_df = alpha_df
    features_df = features_df.drop(features_df.columns[0], axis=1)
    n = features_df.shape[1]
    features_list = [[] for _ in range(n)]
    for i in range(n):
        features_list[i] = (list(set(features_df.ix[:, i].values)))

    # split data into different features
    lists = [[] for _ in range(n * 2)]
    p_list = [[] for _ in range(n)]
    for i in range(len(features_list)):
        for j in range(alpha_df.shape[0]):
            if alpha_df.ix[j][i + 1] == features_list[i][0]:
                lists[i * 2].append(alpha_df.ix[j][0])
            else:
                lists[i * 2 + 1].append(alpha_df.ix[j][0])
    # find p value
    for i in range(n):
        z, p = scipy.stats.ranksums(lists[i * 2], lists[i * 2 + 1])
        p_list[i].append(p)
    p_df = pd.DataFrame(data=p_list, index=features_df.columns.values, columns=['p'])
    p_df.to_csv(path + '/p_alpha.csv', sep='\t')

    # plot alpha diversity
    for i in range(n):
        feature_1 = pd.DataFrame(data=lists[i * 2], index=None, columns=[features_list[i][0]])
        feature_2 = pd.DataFrame(data=lists[i * 2 + 1], index=None, columns=[features_list[i][1]])
        data_df = pd.concat([feature_1, feature_2], axis=1)
        figure(i + 1)
        sns.set(font_scale=1.5)
        ax1 = sns.boxplot(data_df)
        plt.xlabel(alpha_df.columns.values[i + 1], fontsize=20)
        plt.ylabel('Shannon', fontsize=20)
        plt.savefig(path + '/alpha' + alpha_df.columns.values[i + 1] + '.pdf')
        plt.close()


# imput inclue a mdDisMatric dataframe generate before, and a feature_df.cvs created by user
# The first conlum of feature_df.csv is sample ID, which need to in the same order as msDistMatrix.
# The first row of  feature_df.csv is the hearder, and the other columns are different features for each sample.
# feature_df.csv is separate by 'tab'
def beta_analysis(path):
    # match features with each distance data
    distance_df=pd.read_csv(path + '/msDistMatrix.csv',index_col=0)
    feature_df=pd.read_csv(path + '/feature_df.csv',index_col=0,sep='\t')
    n = feature_df.shape[1]
    data = []
    lists_featureid = [[] for _ in range(n * 2)]
    for i in range(distance_df.shape[0] - 1):
        for j in range(i + 1, distance_df.shape[1]):
            data.append(distance_df.ix[i, j])
            for z in range(n):
                lists_featureid[z * 2].append(feature_df.ix[i][z])
                lists_featureid[z * 2 + 1].append(feature_df.ix[j][z])

    # create a feature list
    feature_list = [[] for _ in range(n)]
    for i in range(n):
        feature_list[i] = (list(set(feature_df.ix[:, i].values)))

    # split data for each feature in within or between
    data_featuregroup = [[] for _ in range(n * 2)]
    for i in range(n):
        for j in range(len(data)):
            if lists_featureid[i * 2][j] == lists_featureid[i * 2 + 1][j]:
                data_featuregroup[i * 2].append(data[j])
            else:
                data_featuregroup[i * 2 + 1].append(data[j])

    # effect size
    def cohen_d(x, y):
        nx = len(x)
        ny = len(y)
        dof = nx + ny - 2
        return (mean(x) - mean(y)) / sqrt(((nx - 1) * std(x, ddof=1) ** 2 + (ny - 1) * std(y, ddof=1) ** 2) / dof)

    # plot data
    # function for setting the colors of the box plots pairs
    def set_box_colors(bp):
        setp(bp['boxes'][0], color='blue')
        setp(bp['caps'][0], color='blue')
        setp(bp['caps'][1], color='blue')
        setp(bp['whiskers'][0], color='blue')
        setp(bp['whiskers'][1], color='blue')
        setp(bp['fliers'][0], markeredgecolor='blue')
        setp(bp['medians'][0], color='blue')

        setp(bp['boxes'][1], color='red')
        setp(bp['caps'][2], color='red')
        setp(bp['caps'][3], color='red')
        setp(bp['whiskers'][2], color='red')
        setp(bp['whiskers'][3], color='red')
        setp(bp['fliers'][1], markeredgecolor='red')
        setp(bp['medians'][1], color='red')

    fig = figure()
    ax = axes()
    hold(True)
    sns.set(font_scale=1.5)
    d = []
    for i in range(n):
        data_plot = [data_featuregroup[i * 2], data_featuregroup[i * 2 + 1]]
        bp = boxplot(data_plot, positions=[1 + 3 * i, 2 + 3 * i], widths=0.6)
        set_box_colors(bp)
        effect_size = cohen_d(data_featuregroup[i * 2], data_featuregroup[i * 2 + 1])
        d.append(effect_size)

    def floatrange(start, stop, steps):
        return [start + float(i) * (stop - start) / (float(steps) - 1) for i in range(steps)]

    # set axes limits and labels
    xlim(0, n * 3)
    ylim(0, max(data) + 0.05)
    ax.set_xticklabels(feature_df.columns.values)
    ax.set_xticks(floatrange(1.5, n * 3 - 1.5, 3))
    ax.set_ylabel('Distance')

    # draw temporary red and blue lines and use them to create a legend
    hB, = plot([1, 1], 'b-')
    hR, = plot([1, 1], 'r-')
    legend((hB, hR), ('Within', 'Between'))
    hB.set_visible(False)
    hR.set_visible(False)

    # beta diversity p value from permanova
    # two inputs, distance data and grouping
    distance_data = distance_df.values
    distance_ids = distance_df.index.values
    distance_matrix = skbio.stats.distance.DistanceMatrix(distance_data, distance_ids)
    p_list = []
    for i in range(n):
        grouping = feature_df.ix[:, i].values
        p_beta = skbio.stats.distance.permanova(distance_matrix, grouping, permutations=999)['p-value']
        p_list.append(p_beta)

    # save file
    plt.savefig(path + '/beta_pt.pdf')
    plt.close()
    p_df = pd.DataFrame(data=p_list, index=feature_df.columns.values, columns=['p'])
    e_df = pd.DataFrame(data=d, index=feature_df.columns.values, columns=['Cohens_d'])
    result_df = pd.concat([p_df, e_df], axis=1)
    result_df.to_csv(path+'/beta_data.csv', sep='\t')


# Inputs are the genusAbd.csv, the abundance table, generated before, and a biofeature.csv
# biofeature.csv contains two columns: fist is sample ID and the order is consistent with abundance table
# second is a feature
#  The first row of biofeature is header
# biofeature.csv is separated by 'tab'
def biomarker(path):
    # input is the abundance table. The last column contain the feature infor
    abundance_df = pd.read_csv(path + '/genusAbd.csv',index_col=0)
    feature_df = pd.read_csv(path + '/biofeature.csv',index_col=0,sep='\t')
    feature_list = list(set(feature_df.ix[:, -1].values))
    count_matrix = np.zeros((abundance_df.shape[1], 1))
    for i in range(abundance_df.shape[1]):
        feature = [[] for _ in range(2)]
        for j in range(abundance_df.shape[0]):
            if feature_df.ix[j][-1] == feature_list[0]:
                feature[0].append(abundance_df.ix[j][i])
            else:
                feature[1].append(abundance_df.ix[j][i])
            z_stat, p_val = scipy.stats.ranksums(feature[0], feature[1])
            count_matrix[i] = p_val
    index = abundance_df.columns.values
    sort_df = pd.DataFrame(data=count_matrix, index=index, columns=['P_val'])
    sort_df = sort_df[sort_df['P_val'] <= 0.01].sort_values('P_val')

    # find genus with higher relative abundance
    threshold_id = abundance_df[abundance_df > 0.01]
    threshold_id = threshold_id.dropna(axis=1, thresh=abundance_df.shape[0] / 4).columns.values

    # plot marker with high relative abundance
    p_index = []
    p_list = []
    for i in range(len(threshold_id)):
        f1 = []
        f2 = []
        if threshold_id[i] in sort_df.index.values:
            ab_data = abundance_df[threshold_id[i]]
            p_index.append(threshold_id[i])
            p_list.append(sort_df.ix[threshold_id[i]])
            for j in range(len(ab_data)):
                if feature_df.ix[:, -1][j] == feature_list[0]:
                    f1.append(ab_data[j])
                else:
                    f2.append(ab_data[j])
            f1 = pd.DataFrame(data=f1, index=None, columns=[feature_list[0]])
            f2 = pd.DataFrame(data=f2, index=None, columns=[feature_list[1]])
            data_df = pd.concat([f1, f2], axis=1)
            figure(i + 1)
            sns.set(font_scale = 1.5)
            ax1 = sns.boxplot(data_df, vert = False)
            plt.xlabel('Relative Abundance', fontsize = 20)
            plt.ylabel(feature_df.columns.values[0], fontsize = 20)
            ax1.set_title(threshold_id[i], fontsize = 20)
            # save plots in pdf
            plt.savefig(path + '/biomarker' + threshold_id[i] + '.pdf')
            plt.close()
    # save p value in a csv
    p_df = pd.DataFrame(data=p_list, index=p_index, columns=['P_val'])
    p_df.to_csv(path + '/biomarker.csv', sep = '\t')


# call statistical analysis functions and generate graph report
alpha_analysis(path)
beta_analysis(path)
biomarker(path)
